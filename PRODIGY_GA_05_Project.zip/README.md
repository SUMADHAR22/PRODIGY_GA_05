# PRODIGY_GA_05

## Neural Style Transfer

This project implements Neural Style Transfer using TensorFlow Hub.

## Technologies Used
- Python
- TensorFlow
- TensorFlow Hub
- Google Colab
- Matplotlib

## Features
- Upload content and style images
- Apply artistic style transfer
- Generate stylized AI artwork

## Project Objective
Apply the artistic style of one image to another image using deep learning.

## Author
SUMADHAR
